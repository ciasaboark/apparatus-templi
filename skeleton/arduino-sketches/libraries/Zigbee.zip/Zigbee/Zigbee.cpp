#include "Zigbee.h"

Zigbee::Zigbee(char *newName, uint8_t rx_pin, uint8_t tx_pin) {
    xbee = new XBee();
    softSerial = new SoftwareSerial(rx_pin, tx_pin);
    msr = new ModemStatusResponse();
    response = new XBeeResponse();
    rx = new ZBRxResponse();
    name = (char *)malloc(sizeof(char) * 10);
    if(name != NULL) {
        strcpy(name, newName);
    }
}

Zigbee::~Zigbee() {
	
}

void Zigbee::start(int buad_rate) {
    softSerial->begin(buad_rate); //data transmission rate. defaults to 9600
    /* Im not sure why it wants me to dereference the the pointer when it expects the address */
    xbee->begin(*softSerial); 
}

void Zigbee::sendCommand(String command) {
    int length = command.length();
    char array[length];
    command.toCharArray(array, length);
    sendBinary((uint8_t *)array, length);
}

void Zigbee::sendBinary(uint8_t *command, int length) {
    XBeeAddress64 addr64 = XBeeAddress64(0x00000000, 0x00000000);  //coordinator address
    uint8_t message_fragment[69];
    memset(message_fragment, 0, 69); //zero out the array
    
    message_fragment[0] = (uint8_t)0x0D;
    message_fragment[1] = 0;
    message_fragment[2] = 69; //the length of the message_fragment
    
    for(int y = 4; y < 14; y++) {
        message_fragment[y] = (uint8_t)name[y - 4]; //copy the name into the array indexes
    }

    if(length <= MAX_DATA_SIZE) {
        message_fragment[3] = 0; //the fragment number
        for(int i = 14; i < 69; i++) {
            message_fragment[i] = command[i - 14];
        }
        ZBTxRequest zbTx = ZBTxRequest(addr64, message_fragment, sizeof(message_fragment));
        xbee->send(zbTx);
    }
    else {
        int total_fragments = length / MAX_DATA_SIZE;
        uint8_t message_fragment[69];
        memset(message_fragment, 0, 69); //zero out the array
        
	int index = 0;
        int fragmentNum = 0;
        for(int x = 0; x <= total_fragments - 1; x++) { 
            message_fragment[3] = fragmentNum; //the fragment number
            for(int z = 14; z < 69; z++) {
                message_fragment[z] = command[index];
                index++;
            }
            ZBTxRequest zbTx = ZBTxRequest(addr64, message_fragment, sizeof(message_fragment)); 
            xbee->send(zbTx);
            fragmentNum++;
            
        }
    }	
}

void Zigbee::sendMessageFragment(Message *obj) {
    
}
